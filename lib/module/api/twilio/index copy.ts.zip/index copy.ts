/* eslint-disable @typescript-eslint/no-misused-promises */
import crashlytics from '@react-native-firebase/crashlytics';
import * as api from 'api';
import { AccessToken, Dict } from 'incident-code-core';
import forEach from 'lodash/forEach';
import map from 'lodash/map';
import { Client as TwilioClient } from 'twilio-chat/lib/client';
import { Client } from '@twilio/conversations';

import { Message as TwilioMessage } from 'twilio-chat/lib/message';
import { convertToGiftedChatMessage } from 'utils/chat';
import {
  getTwilioAccessTokenFromStorage,
  isTokenExpired,
  refreshTwilioAccessToken,
  saveTwilioAccessToken,
} from 'utils/token';

import axios from '../axios';
import event, { AppEvent } from '../event';

export const endpoints = {
  twilio: 'twilio',
};
let acountSIDQA = "ACd3c44d10b99e391a58e6d8f297003ebe";
let accountSIDProduction = "ACa428925e0ee550bdc062abc7eb546785";
let acountSID = acountSIDQA;

let client: TwilioClient;

const getToken = (): Promise<AccessToken> =>
  axios
    .post<AccessToken>(`${endpoints.twilio}/auth`)
    .then(response => response.data);

const updateClientToken = async () => {
  const token = await getToken();
  console.log("Twilio token-->",token)
  await client.updateToken(token.access_token || '');
  await saveTwilioAccessToken(token);
};

export default {
  init: async (accessToken: AccessToken) => {
    if (!client) {
      try {
        let token: AccessToken = accessToken;
        if (isTokenExpired(accessToken)) {
          token = await refreshTwilioAccessToken();
        }
        client = await TwilioClient.create(token.access_token || '');
      } catch (error) {
        await updateClientToken();
        await api.logger.logError({
          source: 'Twilio init',
          raw: JSON.stringify(error),
        });
      } finally {
        if (client) {
          client.on('tokenAboutToExpire', updateClientToken);
          client.on('tokenExpired', updateClientToken);
        }
      }
    }
  },
  getToken,
  getMessages: async (incidentId: string) => {
    const token = await getTwilioAccessTokenFromStorage();
    if (isTokenExpired(token)) {
      await updateClientToken();
    }
    const channel = await client.getChannelByUniqueName(incidentId);
    if (channel.status !== 'joined') {
      await channel.join();
    }
    const channelMembers = await channel.getMembers();
    const members: Dict<string> = {};

    forEach(channelMembers, member => {
      members[member.sid] = member.identity;
    });

    const messageAdded = async (message: TwilioMessage) => {
      await channel.setAllMessagesConsumed();
      const giftedChatMessage = convertToGiftedChatMessage(message, members);
      event.emit(AppEvent.OnMessageAdded, giftedChatMessage);
    };

    channel.on('messageAdded', messageAdded);

    const messagePaginator = await channel.getMessages();

    return map(messagePaginator.items, message =>
      convertToGiftedChatMessage(message, members),
    ).reverse();
  },
  sendMessage: async (
    incidentId: string,
    message: string,
    messageAttributes?: Record<string, any>,
  ) => {
    const channel = await client.getChannelByUniqueName(incidentId);
    channel
      .sendMessage(message, messageAttributes)
      .then()
      .catch(error => {
        crashlytics().log('Twilio chat error caught...');
        api.logger.logError({
          source: 'Chat Send Message Error',
          raw: JSON.stringify(error),
          message: error.message,
        });
        crashlytics().recordError(error);
      });
  },
  removeChannelEvents: async (incidentId: string) => {
    try {
      const channel = await client.getChannelByUniqueName(incidentId);
      if (channel) {
        channel.removeAllListeners();
      }
    } catch (e) {
      crashlytics().log('Find channel and remove listeners error');
      crashlytics().recordError(e);
    }
  },
};
